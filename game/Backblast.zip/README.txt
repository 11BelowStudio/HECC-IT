BACKBLAST - A murder mystery where you are the victim!

You've just recieved a mysterious job offer in the post. They're offering you a lot of money, but they're not being very forthcoming with the details. What's the worst that could happen?


Credits:
Written by Rachel Lowe, using HECC-IT.
Partially inspired by the Zero Escape series.

HECC-IT uses Showdown (https://github.com/showdownjs/showdown) within its outputs to handle markdown formatting and such.

Might be a bit rough around the edges. If there's any issues with the game, let me know about it.


Content Warnings:
* Death
* Suicide
* Gets a bit existential